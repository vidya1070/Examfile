package com.example.demo.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.entities.Info;
import com.example.demo.service.InfoService;



public class InfoController {
	
	InfoService Iservice;
@GetMapping("/bfhl")
	
	public List<Info> getAllInfo()
	{
		return Iservice.getAllInfo();
	}

}
