package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Info {
	
private String is_success;
	@Id
private String user_id;;

private String email_id;
 
	private String roll_number;
	private String numbers;
	private String alphabets;
	public Info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Info(String is_success, String user_id, String email_id, String roll_number, String numbers,
			String alphabets) {
		super();
		this.is_success = is_success;
		this.user_id = user_id;
		this.email_id = email_id;
		this.roll_number = roll_number;
		this.numbers = numbers;
		this.alphabets = alphabets;
	}
	public Info(String is_success, String email_id, String roll_number, String numbers, String alphabets) {
		super();
		this.is_success = is_success;
		this.email_id = email_id;
		this.roll_number = roll_number;
		this.numbers = numbers;
		this.alphabets = alphabets;
	}
	public String getIs_success() {
		return is_success;
	}
	public void setIs_success(String is_success) {
		this.is_success = is_success;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getRoll_number() {
		return roll_number;
	}
	public void setRoll_number(String roll_number) {
		this.roll_number = roll_number;
	}
	public String getNumbers() {
		return numbers;
	}
	public void setNumbers(String numbers) {
		this.numbers = numbers;
	}
	public String getAlphabets() {
		return alphabets;
	}
	public void setAlphabets(String alphabets) {
		this.alphabets = alphabets;
	}
	
	

}
